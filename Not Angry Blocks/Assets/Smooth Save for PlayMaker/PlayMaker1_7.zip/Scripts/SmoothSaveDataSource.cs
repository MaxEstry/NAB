﻿// PM 1.7
/*
 *  Smooth Save for PlayMaker
 *
 *  Copyright 2015 Christopher Stanley
 *
 *  Documentation: "Smooth Save Manual.pdf"
 *
 *  Support: support@ChristopherCreates.com
 */


using HutongGames.PlayMaker;
using System;
using System.Collections.Generic;
using UnityEngine;
#if !UNITY_4_5 && !UNITY_4_6 && !UNITY_4_7 && !UNITY_5_0 && !UNITY_5_1 && !UNITY_5_2
using UnityEngine.SceneManagement;
#endif

namespace ChristopherCreates.SmoothSave
{
	[Serializable]
	public class SmoothSaveDataSource
	{
		public VariableType FsmVariableType { get; set; }
		public string Key { get; set; }
		public string FsmVariableName { get; set; }
		public bool IsGlobal { get; set; }
		public string SceneName { get; set; }
		public string OwnerName { get; set; }
		public string FsmName { get; set; }

		public object[] _serializedValue;

		[NonSerialized]
		NamedVariable _fsmVariable;

		[NonSerialized]
		static readonly Dictionary<VariableType, int> _dataTypeSizes = new Dictionary<VariableType, int>
		{
			{ VariableType.Bool, 1 },
            { VariableType.Color, 4 },
			{ VariableType.Float, 1 },
			{ VariableType.Int, 1 },
			{ VariableType.Quaternion, 4 },
			{ VariableType.Rect, 4 },
			{ VariableType.String, 1 },
			{ VariableType.Vector2, 2 },
			{ VariableType.Vector3, 3 }
		};


		// Deserialized from XML
		public SmoothSaveDataSource()
		{
		}

		public SmoothSaveDataSource(NamedVariable fsmVariable, string key, bool isGlobal, Fsm fsm)
		{
			/*
			Variables have three categories of identification
				Type	ID
				Keyed	Variable Type + Key
				Global	Variable Type + Variable Name + Global
				Local	Variable Type + Variable Name + Local + Level + Owner + FSM
			*/

			// Check common data
			if (fsmVariable == null)
				throw new ArgumentNullException("fsmVariable", "Cannot create data source for null FSM variable");

			// Assign common properties
			_fsmVariable = fsmVariable;
			FsmVariableType = FsmUtility.GetVariableType(_fsmVariable);
			Key = StringEmptyToNull(key);

			// If keyed, serialize and exit
			if (Key != null)
			{
				Serialize();
				return;
			}

			// Assign global and local properties
			IsGlobal = isGlobal;
			FsmVariableName = fsmVariable.Name;

			// Check global and local data
			if (string.IsNullOrEmpty(FsmVariableName))
				throw new ArgumentNullException("fsmVariable.Name", "Cannot create global or FSM data source with null or empty FSM variable name");

			// If global, serialize and exit
			if (IsGlobal)
			{
				Serialize();
				return;
			}

			// Check local data
			if (fsm == null)
				throw new ArgumentNullException("fsm", "Cannot create FSM data source with null or empty FSM");

			// Assign local properties
#if UNITY_4_5 || UNITY_4_6 || UNITY_4_7 || UNITY_5_0 || UNITY_5_1 || UNITY_5_2
			SceneName = StringEmptyToNull(Application.loadedLevelName);
#else
			SceneName = StringEmptyToNull(SceneManager.GetActiveScene().name);
#endif
			OwnerName = StringEmptyToNull(fsm.OwnerName);
			FsmName = StringEmptyToNull(fsm.Name);

			// Check local data
			if (SceneName == null)
				throw new NotSupportedException("Cannot create FSM data source without named scene");
			if (OwnerName == null)
				throw new ArgumentNullException("fsm.OwnerName", "Cannot create FSM data source with null or empty owner name");
			if (FsmName == null)
				throw new ArgumentNullException("fsm.Name", "Cannot create FSM data source with null or empty FSM name");

			// Serialize and exit
			Serialize();
		}


		// Make variable from saved data
		public bool MatchSignature(SmoothSaveDataSource dataSource, bool logMismatch = false)
		{
			// Check data
			if (dataSource == null)
				throw new ArgumentNullException("dataSource", "Cannot match signature of null data source");

			// Check each property
			string errorMessage = null;

			if (FsmVariableType != dataSource.FsmVariableType)
				errorMessage = "Variable type mismatch";
			else if (Key != dataSource.Key)
				errorMessage = "Key mismatch";
			else if (FsmVariableName != dataSource.FsmVariableName)
				errorMessage = "Variable name mismatch";
			else if (IsGlobal != dataSource.IsGlobal)
				errorMessage = "Global mismatch";
			else if (SceneName != dataSource.SceneName)
				errorMessage = "Level name mismatch";
			else if (OwnerName != dataSource.OwnerName)
				errorMessage = "Owner name mismatch";
			else if (FsmName != dataSource.FsmName)
				errorMessage = "FSM name mismatch";

			// Test mismatch
			if (errorMessage != null)
			{
				if (logMismatch)
					Debug.LogWarning(errorMessage);
				return false;
			}

			// It's a match!
			return true;
		}


		// Set data source
		public void SetFsmVariable(SmoothSaveDataSource dataSource)
		{
			// Check data source
			if (dataSource == null)
				throw new ArgumentNullException("dataSource", "Cannot set FSM variable from null data source");
			if (FsmVariableType != dataSource.FsmVariableType)
				throw new ArgumentException("Cannot set FSM variable from data source of different type. Old type: " + FsmVariableType + ", New Type: " + dataSource.FsmVariableType);

			// Get FSM variable
			var fsmVariable = dataSource.GetFsmVariable();
			if (fsmVariable == null)
				throw new ArgumentNullException("dataSource.GetFsmVariable()", "Cannot set FSM variable from data source with null FSM variable");
			_fsmVariable = fsmVariable;
		}


		// Get FSM variable
		public NamedVariable GetFsmVariable()
		{
			return _fsmVariable;
		}


		// Get serialized data
		public object[] GetRawData()
		{
			return _serializedValue;
		}


		// Break data source into an object array
		public void Serialize()
		{
			// Check data
			if (_fsmVariable == null)
				throw new InvalidOperationException("Cannot serialize null FSM variable");
			if (GetFsmVariableValue(_fsmVariable) == null)
				throw new InvalidOperationException("Cannot serialize unassigned FSM variable");

			var rawValue = GetFsmVariableValue(_fsmVariable);
			switch (FsmVariableType)
			{
				case VariableType.Bool:
				case VariableType.Float:
				case VariableType.Int:
				case VariableType.String:
					_serializedValue = new object[] { rawValue };
					return;
				case VariableType.Color:
					var color = (Color)rawValue;
					_serializedValue = new object[] { color.r, color.g, color.b, color.a };
					return;
				case VariableType.Quaternion:
					var quaternion = (Quaternion)rawValue;
					_serializedValue = new object[] { quaternion.x, quaternion.y, quaternion.z, quaternion.w };
					return;
				case VariableType.Rect:
					var rect = (Rect)rawValue;
					_serializedValue = new object[] { rect.x, rect.y, rect.width, rect.height };
					return;
				case VariableType.Vector2:
					var vector2 = (Vector2)rawValue;
					_serializedValue = new object[] { vector2.x, vector2.y };
					return;
				case VariableType.Vector3:
					var vector3 = (Vector3)rawValue;
					_serializedValue = new object[] { vector3.x, vector3.y, vector3.z };
					return;
				default:
					throw new NotSupportedException("Invalid FSM variable type: " + FsmVariableType);
			}
		}


		// Make data source from an object array
		public object Deserialize()
		{
			// Check data
			if (_serializedValue == null)
				throw new InvalidOperationException("Cannot deserialize null data");
			if (_serializedValue.Length != _dataTypeSizes[FsmVariableType])
				throw new InvalidOperationException("Data size does not match data type.  Expected size: " + _dataTypeSizes[FsmVariableType] + ", Actual size: " + _serializedValue.Length);

			object deserializedValue;

			// If basic type, return it
			switch (FsmVariableType)
			{
				case VariableType.Bool:
				case VariableType.Float:
				case VariableType.Int:
				case VariableType.String:
					deserializedValue = _serializedValue[0];
					if (_fsmVariable != null)
						SetFsmVariableValue(_fsmVariable, deserializedValue);
					return deserializedValue;
			}

			// Build complex types
			var floats = Array.ConvertAll(_serializedValue, element => (float)element);
			switch (FsmVariableType)
			{
				case VariableType.Color:
					deserializedValue = new Color(floats[0], floats[1], floats[2], floats[3]);
					break;
				case VariableType.Quaternion:
					deserializedValue = new Quaternion(floats[0], floats[1], floats[2], floats[3]);
					break;
				case VariableType.Rect:
					deserializedValue = new Rect(floats[0], floats[1], floats[2], floats[3]);
					break;
				case VariableType.Vector2:
					deserializedValue = new Vector2(floats[0], floats[1]);
					break;
				case VariableType.Vector3:
					deserializedValue = new Vector3(floats[0], floats[1], floats[2]);
					break;
				default:
					throw new NotSupportedException("Invalid FSM variable type: " + FsmVariableType);
			}
			if (_fsmVariable != null)
				SetFsmVariableValue(_fsmVariable, deserializedValue);
			return deserializedValue;
        }


		// Get Value property of FSM variable
		object GetFsmVariableValue(NamedVariable fsmVariable)
		{
			var fsmVariableType = fsmVariable.GetType();
			if (fsmVariableType == typeof(FsmBool))
				return ((FsmBool)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmColor))
				return ((FsmColor)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmFloat))
				return ((FsmFloat)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmInt))
				return ((FsmInt)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmQuaternion))
				return ((FsmQuaternion)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmRect))
				return ((FsmRect)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmString))
				return ((FsmString)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmVector2))
				return ((FsmVector2)fsmVariable).Value;
			else if (fsmVariableType == typeof(FsmVector3))
				return ((FsmVector3)fsmVariable).Value;
			else
				throw new NotSupportedException("Invalid FSM variable type: " + fsmVariableType);
		}


		// Set Value property of FSM variable
		void SetFsmVariableValue(NamedVariable fsmVariable, object value)
		{
			var fsmVariableType = fsmVariable.GetType();
			if (fsmVariableType == typeof(FsmBool))
				((FsmBool)fsmVariable).Value = (bool)value;
			else if (fsmVariableType == typeof(FsmColor))
				((FsmColor)fsmVariable).Value = (Color)value;
			else if (fsmVariableType == typeof(FsmFloat))
				((FsmFloat)fsmVariable).Value = (float)value;
			else if (fsmVariableType == typeof(FsmInt))
				((FsmInt)fsmVariable).Value = (int)value;
			else if (fsmVariableType == typeof(FsmQuaternion))
				((FsmQuaternion)fsmVariable).Value = (Quaternion)value;
			else if (fsmVariableType == typeof(FsmRect))
				((FsmRect)fsmVariable).Value = (Rect)value;
			else if (fsmVariableType == typeof(FsmString))
				((FsmString)fsmVariable).Value = (string)value;
			else if (fsmVariableType == typeof(FsmVector2))
				((FsmVector2)fsmVariable).Value = (Vector2)value;
			else if (fsmVariableType == typeof(FsmVector3))
				((FsmVector3)fsmVariable).Value = (Vector3)value;
			else
				throw new NotSupportedException("Invalid FSM variable type: " + fsmVariableType);
		}


		// Convert empty string to null
		static string StringEmptyToNull(string target)
		{
			if (target == "")
				return null;
			else
				return target;
		}
	}
}
